import { View, Text } from 'react-native'
import React from 'react'

export default function Notifications() {
  return (
    <View style={{flex:1, alignItems:'center', alignContent:'center'}}>
      <Text>Notifications</Text>
    </View>
  )
}